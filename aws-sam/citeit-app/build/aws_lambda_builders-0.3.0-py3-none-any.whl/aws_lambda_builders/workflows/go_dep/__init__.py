"""
Builds Go Lambda functions using the `dep` dependency manager
"""

from .workflow import GoDepWorkflow

# flake8: noqa

from samtranslator.intrinsics.resolver import IntrinsicsResolver

from samtranslator.model.intrinsics import is_instrinsic as is_intrinsics

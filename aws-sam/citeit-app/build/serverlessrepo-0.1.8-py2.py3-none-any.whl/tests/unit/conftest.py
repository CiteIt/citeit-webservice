import os

# set expected aws region environment variable
os.environ['AWS_DEFAULT_REGION'] = 'us-east-1'
